-- Add image column to product table
ALTER TABLE product ADD COLUMN product_image VARCHAR(255) DEFAULT NULL;